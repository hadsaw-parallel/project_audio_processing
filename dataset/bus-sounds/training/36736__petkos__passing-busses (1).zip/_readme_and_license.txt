Sound pack downloaded from Freesound
----------------------------------------

"Passing Busses"

This pack of sounds contains sounds by the following user:
 - PetKos ( https://freesound.org/people/PetKos/ )

You can find this pack online at: https://freesound.org/people/PetKos/packs/36736/


Pack description
----------------

Collection of sounds of passing busses.


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 657522__petkos__passingbus9.wav
    * url: https://freesound.org/s/657522/
    * license: Creative Commons 0
  * 657520__petkos__passingbus5.wav
    * url: https://freesound.org/s/657520/
    * license: Creative Commons 0
  * 657519__petkos__passingbus6.wav
    * url: https://freesound.org/s/657519/
    * license: Creative Commons 0
  * 657518__petkos__passingbus7.wav
    * url: https://freesound.org/s/657518/
    * license: Creative Commons 0
  * 657517__petkos__passingbus8.wav
    * url: https://freesound.org/s/657517/
    * license: Creative Commons 0
  * 657516__petkos__passingbus2.wav
    * url: https://freesound.org/s/657516/
    * license: Creative Commons 0
  * 657515__petkos__passingbus20.wav
    * url: https://freesound.org/s/657515/
    * license: Creative Commons 0
  * 657514__petkos__passingbus3.wav
    * url: https://freesound.org/s/657514/
    * license: Creative Commons 0
  * 657513__petkos__passingbus4.wav
    * url: https://freesound.org/s/657513/
    * license: Creative Commons 0
  * 657470__petkos__passingbus18.wav
    * url: https://freesound.org/s/657470/
    * license: Creative Commons 0
  * 657469__petkos__passingbus19.wav
    * url: https://freesound.org/s/657469/
    * license: Creative Commons 0
  * 657468__petkos__passingbus14.wav
    * url: https://freesound.org/s/657468/
    * license: Creative Commons 0
  * 657467__petkos__passingbus15.wav
    * url: https://freesound.org/s/657467/
    * license: Creative Commons 0
  * 657466__petkos__passingbus16.wav
    * url: https://freesound.org/s/657466/
    * license: Creative Commons 0
  * 657465__petkos__passingbus17.wav
    * url: https://freesound.org/s/657465/
    * license: Creative Commons 0
  * 657464__petkos__passingbus10.wav
    * url: https://freesound.org/s/657464/
    * license: Creative Commons 0
  * 657463__petkos__passingbus11.wav
    * url: https://freesound.org/s/657463/
    * license: Creative Commons 0
  * 657462__petkos__passingbus12.wav
    * url: https://freesound.org/s/657462/
    * license: Creative Commons 0
  * 657461__petkos__passingbus13.wav
    * url: https://freesound.org/s/657461/
    * license: Creative Commons 0
  * 657457__petkos__passingbus1.wav
    * url: https://freesound.org/s/657457/
    * license: Creative Commons 0


