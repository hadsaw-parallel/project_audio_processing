Sound pack downloaded from Freesound
----------------------------------------

"bus_class"

This pack of sounds contains sounds by the following user:
 - hnminh ( https://freesound.org/people/hnminh/ )

You can find this pack online at: https://freesound.org/people/hnminh/packs/36821/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 659159__hnminh__bus3.wav
    * url: https://freesound.org/s/659159/
    * license: Creative Commons 0
  * 659158__hnminh__bus9.wav
    * url: https://freesound.org/s/659158/
    * license: Creative Commons 0
  * 659157__hnminh__bus5.wav
    * url: https://freesound.org/s/659157/
    * license: Creative Commons 0
  * 659156__hnminh__bus4.wav
    * url: https://freesound.org/s/659156/
    * license: Creative Commons 0
  * 659155__hnminh__bus7.wav
    * url: https://freesound.org/s/659155/
    * license: Creative Commons 0
  * 659154__hnminh__bus20.wav
    * url: https://freesound.org/s/659154/
    * license: Creative Commons 0
  * 659153__hnminh__bus6.wav
    * url: https://freesound.org/s/659153/
    * license: Creative Commons 0
  * 659152__hnminh__bus19.wav
    * url: https://freesound.org/s/659152/
    * license: Creative Commons 0
  * 659151__hnminh__bus8.wav
    * url: https://freesound.org/s/659151/
    * license: Creative Commons 0
  * 659150__hnminh__bus2.wav
    * url: https://freesound.org/s/659150/
    * license: Creative Commons 0
  * 659149__hnminh__bus17.wav
    * url: https://freesound.org/s/659149/
    * license: Creative Commons 0
  * 659148__hnminh__bus18.wav
    * url: https://freesound.org/s/659148/
    * license: Creative Commons 0
  * 659147__hnminh__bus13.wav
    * url: https://freesound.org/s/659147/
    * license: Creative Commons 0
  * 659146__hnminh__bus14.wav
    * url: https://freesound.org/s/659146/
    * license: Creative Commons 0
  * 659145__hnminh__bus15.wav
    * url: https://freesound.org/s/659145/
    * license: Creative Commons 0
  * 659144__hnminh__bus16.wav
    * url: https://freesound.org/s/659144/
    * license: Creative Commons 0
  * 659143__hnminh__bus1.wav
    * url: https://freesound.org/s/659143/
    * license: Creative Commons 0
  * 659142__hnminh__bus10.wav
    * url: https://freesound.org/s/659142/
    * license: Creative Commons 0
  * 659141__hnminh__bus11.wav
    * url: https://freesound.org/s/659141/
    * license: Creative Commons 0
  * 659140__hnminh__bus12.wav
    * url: https://freesound.org/s/659140/
    * license: Creative Commons 0
  * 658900__hnminh__bus-24.m4a
    * url: https://freesound.org/s/658900/
    * license: Creative Commons 0
  * 658899__hnminh__bus-8.m4a
    * url: https://freesound.org/s/658899/
    * license: Creative Commons 0
  * 658898__hnminh__bus-3.m4a
    * url: https://freesound.org/s/658898/
    * license: Creative Commons 0
  * 658897__hnminh__bus-25.m4a
    * url: https://freesound.org/s/658897/
    * license: Creative Commons 0
  * 658896__hnminh__bus-6.m4a
    * url: https://freesound.org/s/658896/
    * license: Creative Commons 0
  * 658895__hnminh__bus-23.m4a
    * url: https://freesound.org/s/658895/
    * license: Creative Commons 0
  * 658894__hnminh__bus-5.m4a
    * url: https://freesound.org/s/658894/
    * license: Creative Commons 0
  * 658893__hnminh__bus-21.m4a
    * url: https://freesound.org/s/658893/
    * license: Creative Commons 0
  * 658892__hnminh__bus-7.m4a
    * url: https://freesound.org/s/658892/
    * license: Creative Commons 0
  * 658891__hnminh__bus-22.m4a
    * url: https://freesound.org/s/658891/
    * license: Creative Commons 0
  * 658890__hnminh__bus-19.m4a
    * url: https://freesound.org/s/658890/
    * license: Creative Commons 0
  * 658889__hnminh__bus-20.m4a
    * url: https://freesound.org/s/658889/
    * license: Creative Commons 0
  * 658888__hnminh__bus-13.m4a
    * url: https://freesound.org/s/658888/
    * license: Creative Commons 0
  * 658887__hnminh__bus-15.m4a
    * url: https://freesound.org/s/658887/
    * license: Creative Commons 0
  * 658886__hnminh__bus-16.m4a
    * url: https://freesound.org/s/658886/
    * license: Creative Commons 0
  * 658885__hnminh__bus-18.m4a
    * url: https://freesound.org/s/658885/
    * license: Creative Commons 0
  * 658884__hnminh__bus-1.m4a
    * url: https://freesound.org/s/658884/
    * license: Creative Commons 0
  * 658883__hnminh__bus-10.m4a
    * url: https://freesound.org/s/658883/
    * license: Creative Commons 0
  * 658882__hnminh__bus-11.m4a
    * url: https://freesound.org/s/658882/
    * license: Creative Commons 0
  * 658881__hnminh__bus-12.m4a
    * url: https://freesound.org/s/658881/
    * license: Creative Commons 0


