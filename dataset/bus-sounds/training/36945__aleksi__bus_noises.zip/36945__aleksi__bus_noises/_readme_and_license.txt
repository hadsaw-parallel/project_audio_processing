Sound pack downloaded from Freesound
----------------------------------------

"bus_noises"

This pack of sounds contains sounds by the following user:
 - aleksi____ ( https://freesound.org/people/aleksi____/ )

You can find this pack online at: https://freesound.org/people/aleksi____/packs/36945/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 661849__aleksi__buss-1.wav
    * url: https://freesound.org/s/661849/
    * license: Creative Commons 0
  * 661141__aleksi__bussi3.wav
    * url: https://freesound.org/s/661141/
    * license: Creative Commons 0
  * 661140__aleksi__bussi9.wav
    * url: https://freesound.org/s/661140/
    * license: Creative Commons 0
  * 661139__aleksi__bussi5.wav
    * url: https://freesound.org/s/661139/
    * license: Creative Commons 0
  * 661138__aleksi__bussi4.wav
    * url: https://freesound.org/s/661138/
    * license: Creative Commons 0
  * 661137__aleksi__bussi7.wav
    * url: https://freesound.org/s/661137/
    * license: Creative Commons 0
  * 661136__aleksi__bussi2.wav
    * url: https://freesound.org/s/661136/
    * license: Creative Commons 0
  * 661135__aleksi__bussi6.wav
    * url: https://freesound.org/s/661135/
    * license: Creative Commons 0
  * 661134__aleksi__bussi1.wav
    * url: https://freesound.org/s/661134/
    * license: Creative Commons 0
  * 661133__aleksi__bussi8.wav
    * url: https://freesound.org/s/661133/
    * license: Creative Commons 0
  * 661132__aleksi__bussi10.wav
    * url: https://freesound.org/s/661132/
    * license: Creative Commons 0
  * 661131__aleksi__buss8.wav
    * url: https://freesound.org/s/661131/
    * license: Creative Commons 0
  * 661130__aleksi__buss9.wav
    * url: https://freesound.org/s/661130/
    * license: Creative Commons 0
  * 661129__aleksi__buss4.wav
    * url: https://freesound.org/s/661129/
    * license: Creative Commons 0
  * 661128__aleksi__buss5.wav
    * url: https://freesound.org/s/661128/
    * license: Creative Commons 0
  * 661127__aleksi__buss6.wav
    * url: https://freesound.org/s/661127/
    * license: Creative Commons 0
  * 661126__aleksi__buss7.wav
    * url: https://freesound.org/s/661126/
    * license: Creative Commons 0
  * 661125__aleksi__buss10.wav
    * url: https://freesound.org/s/661125/
    * license: Creative Commons 0
  * 661124__aleksi__buss2.wav
    * url: https://freesound.org/s/661124/
    * license: Creative Commons 0
  * 661123__aleksi__buss3.wav
    * url: https://freesound.org/s/661123/
    * license: Creative Commons 0


