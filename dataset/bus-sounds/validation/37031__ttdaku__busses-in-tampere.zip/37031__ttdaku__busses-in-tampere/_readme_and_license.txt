Sound pack downloaded from Freesound
----------------------------------------

"Busses in Tampere"

This pack of sounds contains sounds by the following user:
 - ttdaku ( https://freesound.org/people/ttdaku/ )

You can find this pack online at: https://freesound.org/people/ttdaku/packs/37031/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 662690__ttdaku__bus3.wav
    * url: https://freesound.org/s/662690/
    * license: Creative Commons 0
  * 662689__ttdaku__bus9.wav
    * url: https://freesound.org/s/662689/
    * license: Creative Commons 0
  * 662688__ttdaku__bus5.wav
    * url: https://freesound.org/s/662688/
    * license: Creative Commons 0
  * 662687__ttdaku__bus4.wav
    * url: https://freesound.org/s/662687/
    * license: Creative Commons 0
  * 662686__ttdaku__bus7.wav
    * url: https://freesound.org/s/662686/
    * license: Creative Commons 0
  * 662685__ttdaku__bus20.wav
    * url: https://freesound.org/s/662685/
    * license: Creative Commons 0
  * 662684__ttdaku__bus6.wav
    * url: https://freesound.org/s/662684/
    * license: Creative Commons 0
  * 662683__ttdaku__bus19.wav
    * url: https://freesound.org/s/662683/
    * license: Creative Commons 0
  * 662682__ttdaku__bus8.wav
    * url: https://freesound.org/s/662682/
    * license: Creative Commons 0
  * 662681__ttdaku__bus2.wav
    * url: https://freesound.org/s/662681/
    * license: Creative Commons 0
  * 662680__ttdaku__bus17.wav
    * url: https://freesound.org/s/662680/
    * license: Creative Commons 0
  * 662679__ttdaku__bus18.wav
    * url: https://freesound.org/s/662679/
    * license: Creative Commons 0
  * 662678__ttdaku__bus13.wav
    * url: https://freesound.org/s/662678/
    * license: Creative Commons 0
  * 662677__ttdaku__bus14.wav
    * url: https://freesound.org/s/662677/
    * license: Creative Commons 0
  * 662676__ttdaku__bus15.wav
    * url: https://freesound.org/s/662676/
    * license: Creative Commons 0
  * 662675__ttdaku__bus16.wav
    * url: https://freesound.org/s/662675/
    * license: Creative Commons 0
  * 662674__ttdaku__bus1.wav
    * url: https://freesound.org/s/662674/
    * license: Creative Commons 0
  * 662673__ttdaku__bus10.wav
    * url: https://freesound.org/s/662673/
    * license: Creative Commons 0
  * 662672__ttdaku__bus11.wav
    * url: https://freesound.org/s/662672/
    * license: Creative Commons 0
  * 662671__ttdaku__bus12.wav
    * url: https://freesound.org/s/662671/
    * license: Creative Commons 0


