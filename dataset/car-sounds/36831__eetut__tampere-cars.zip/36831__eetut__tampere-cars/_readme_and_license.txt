Sound pack downloaded from Freesound
----------------------------------------

"Tampere cars"

This pack of sounds contains sounds by the following user:
 - eetut ( https://freesound.org/people/eetut/ )

You can find this pack online at: https://freesound.org/people/eetut/packs/36831/


Pack description
----------------

Name is self explanatory


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 657095__eetut__car22.wav
    * url: https://freesound.org/s/657095/
    * license: Creative Commons 0
  * 657094__eetut__car21.wav
    * url: https://freesound.org/s/657094/
    * license: Creative Commons 0
  * 657093__eetut__car19.wav
    * url: https://freesound.org/s/657093/
    * license: Creative Commons 0
  * 657092__eetut__car20.wav
    * url: https://freesound.org/s/657092/
    * license: Creative Commons 0
  * 657091__eetut__car15.wav
    * url: https://freesound.org/s/657091/
    * license: Creative Commons 0
  * 657090__eetut__car16.wav
    * url: https://freesound.org/s/657090/
    * license: Creative Commons 0
  * 657089__eetut__car17.wav
    * url: https://freesound.org/s/657089/
    * license: Creative Commons 0
  * 657088__eetut__car18.wav
    * url: https://freesound.org/s/657088/
    * license: Creative Commons 0
  * 657087__eetut__car11.wav
    * url: https://freesound.org/s/657087/
    * license: Creative Commons 0
  * 657086__eetut__car12.wav
    * url: https://freesound.org/s/657086/
    * license: Creative Commons 0
  * 657085__eetut__car13.wav
    * url: https://freesound.org/s/657085/
    * license: Creative Commons 0
  * 657084__eetut__car14.wav
    * url: https://freesound.org/s/657084/
    * license: Creative Commons 0
  * 657081__eetut__car10.wav
    * url: https://freesound.org/s/657081/
    * license: Creative Commons 0
  * 657080__eetut__car6.wav
    * url: https://freesound.org/s/657080/
    * license: Creative Commons 0
  * 657079__eetut__car7.wav
    * url: https://freesound.org/s/657079/
    * license: Creative Commons 0
  * 657078__eetut__car3.wav
    * url: https://freesound.org/s/657078/
    * license: Creative Commons 0
  * 657077__eetut__car4.wav
    * url: https://freesound.org/s/657077/
    * license: Creative Commons 0
  * 657076__eetut__car5.wav
    * url: https://freesound.org/s/657076/
    * license: Creative Commons 0
  * 657075__eetut__car2.wav
    * url: https://freesound.org/s/657075/
    * license: Creative Commons 0
  * 657074__eetut__car8.wav
    * url: https://freesound.org/s/657074/
    * license: Creative Commons 0
  * 657073__eetut__car1.wav
    * url: https://freesound.org/s/657073/
    * license: Creative Commons 0


