Sound pack downloaded from Freesound
----------------------------------------

"Car sounds"

This pack of sounds contains sounds by the following user:
 - ovpe100 ( https://freesound.org/people/ovpe100/ )

You can find this pack online at: https://freesound.org/people/ovpe100/packs/39994/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 715757__ovpe100__car-25.wav
    * url: https://freesound.org/s/715757/
    * license: Creative Commons 0
  * 715756__ovpe100__car-24.wav
    * url: https://freesound.org/s/715756/
    * license: Creative Commons 0
  * 715755__ovpe100__car-23.wav
    * url: https://freesound.org/s/715755/
    * license: Creative Commons 0
  * 715754__ovpe100__car-22.wav
    * url: https://freesound.org/s/715754/
    * license: Creative Commons 0
  * 715753__ovpe100__car-21.wav
    * url: https://freesound.org/s/715753/
    * license: Creative Commons 0
  * 715752__ovpe100__car-20.wav
    * url: https://freesound.org/s/715752/
    * license: Creative Commons 0
  * 715751__ovpe100__car-19.wav
    * url: https://freesound.org/s/715751/
    * license: Creative Commons 0
  * 715750__ovpe100__car-18.wav
    * url: https://freesound.org/s/715750/
    * license: Creative Commons 0
  * 715749__ovpe100__car-17.wav
    * url: https://freesound.org/s/715749/
    * license: Creative Commons 0
  * 715748__ovpe100__car-16.wav
    * url: https://freesound.org/s/715748/
    * license: Creative Commons 0
  * 715747__ovpe100__car-15.wav
    * url: https://freesound.org/s/715747/
    * license: Creative Commons 0
  * 715746__ovpe100__car-14.wav
    * url: https://freesound.org/s/715746/
    * license: Creative Commons 0
  * 715745__ovpe100__car-13.wav
    * url: https://freesound.org/s/715745/
    * license: Creative Commons 0
  * 715744__ovpe100__car-12.wav
    * url: https://freesound.org/s/715744/
    * license: Creative Commons 0
  * 715743__ovpe100__car-11.wav
    * url: https://freesound.org/s/715743/
    * license: Creative Commons 0
  * 715742__ovpe100__car-10.wav
    * url: https://freesound.org/s/715742/
    * license: Creative Commons 0
  * 715741__ovpe100__car-9.wav
    * url: https://freesound.org/s/715741/
    * license: Creative Commons 0
  * 715740__ovpe100__car-8.wav
    * url: https://freesound.org/s/715740/
    * license: Creative Commons 0
  * 715739__ovpe100__car-7.wav
    * url: https://freesound.org/s/715739/
    * license: Creative Commons 0
  * 715738__ovpe100__car-6.wav
    * url: https://freesound.org/s/715738/
    * license: Creative Commons 0
  * 715737__ovpe100__car-5.wav
    * url: https://freesound.org/s/715737/
    * license: Creative Commons 0
  * 715736__ovpe100__car-4.wav
    * url: https://freesound.org/s/715736/
    * license: Creative Commons 0
  * 715735__ovpe100__car-3.wav
    * url: https://freesound.org/s/715735/
    * license: Creative Commons 0
  * 715734__ovpe100__car-2.wav
    * url: https://freesound.org/s/715734/
    * license: Creative Commons 0
  * 715733__ovpe100__car-1.wav
    * url: https://freesound.org/s/715733/
    * license: Creative Commons 0


