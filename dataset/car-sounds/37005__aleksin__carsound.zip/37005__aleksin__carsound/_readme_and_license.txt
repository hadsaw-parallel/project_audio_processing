Sound pack downloaded from Freesound
----------------------------------------

"carsound"

This pack of sounds contains sounds by the following user:
 - aleksin ( https://freesound.org/people/aleksin/ )

You can find this pack online at: https://freesound.org/people/aleksin/packs/37005/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 662187__aleksin__auto6.wav
    * url: https://freesound.org/s/662187/
    * license: Creative Commons 0
  * 662186__aleksin__auto7.wav
    * url: https://freesound.org/s/662186/
    * license: Creative Commons 0
  * 662184__aleksin__auto22.wav
    * url: https://freesound.org/s/662184/
    * license: Creative Commons 0
  * 662183__aleksin__auto3.wav
    * url: https://freesound.org/s/662183/
    * license: Creative Commons 0
  * 662182__aleksin__auto4.wav
    * url: https://freesound.org/s/662182/
    * license: Creative Commons 0
  * 662181__aleksin__auto5.wav
    * url: https://freesound.org/s/662181/
    * license: Creative Commons 0
  * 662180__aleksin__auto19.wav
    * url: https://freesound.org/s/662180/
    * license: Creative Commons 0
  * 662179__aleksin__auto2.wav
    * url: https://freesound.org/s/662179/
    * license: Creative Commons 0
  * 662178__aleksin__auto20.wav
    * url: https://freesound.org/s/662178/
    * license: Creative Commons 0
  * 662177__aleksin__auto21.wav
    * url: https://freesound.org/s/662177/
    * license: Creative Commons 0
  * 662176__aleksin__auto9.wav
    * url: https://freesound.org/s/662176/
    * license: Creative Commons 0
  * 662175__aleksin__auto8.wav
    * url: https://freesound.org/s/662175/
    * license: Creative Commons 0
  * 662174__aleksin__auto17.wav
    * url: https://freesound.org/s/662174/
    * license: Creative Commons 0
  * 662173__aleksin__auto18.wav
    * url: https://freesound.org/s/662173/
    * license: Creative Commons 0
  * 662172__aleksin__auto13.wav
    * url: https://freesound.org/s/662172/
    * license: Creative Commons 0
  * 662171__aleksin__auto14.wav
    * url: https://freesound.org/s/662171/
    * license: Creative Commons 0
  * 662170__aleksin__auto15.wav
    * url: https://freesound.org/s/662170/
    * license: Creative Commons 0
  * 662169__aleksin__auto16.wav
    * url: https://freesound.org/s/662169/
    * license: Creative Commons 0
  * 662168__aleksin__auto1.wav
    * url: https://freesound.org/s/662168/
    * license: Creative Commons 0
  * 662167__aleksin__auto10.wav
    * url: https://freesound.org/s/662167/
    * license: Creative Commons 0
  * 662166__aleksin__auto11.wav
    * url: https://freesound.org/s/662166/
    * license: Creative Commons 0
  * 662165__aleksin__auto12.wav
    * url: https://freesound.org/s/662165/
    * license: Creative Commons 0


